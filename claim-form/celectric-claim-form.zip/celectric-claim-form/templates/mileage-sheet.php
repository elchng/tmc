<?php
/**
 * Mileage Claim sheet (layout 2): the Excel "Mileage Claim" form with the
 * vehicle chosen on each trip, an amount per trip and a per-vehicle summary.
 * Claims saved before this layout print with mileage-v1-sheet.php.
 *
 *  - $mode = 'edit'  : cells contain inputs (on phones the CSS restacks them).
 *  - $mode = 'print' : cells contain the saved values, rates and totals.
 *
 * Expects: $mode, $claim (array).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$edit     = ( 'edit' === $mode );
$vehicles = cel_claim_vehicle_rates();
$purposes = cel_claim_mileage_purposes();
$trips    = isset( $claim['trips'] ) ? array_values( $claim['trips'] ) : array();
$rows     = $edit ? max( (int) cel_claim_setting( 'mileage_rows' ), count( $trips ) ) : max( 16, count( $trips ) );
$first    = (string) cel_claim_first_key( $vehicles );

if ( $edit ) {
	// Totals for what is on screen (after a failed submit), using today's rates.
	$by = array_fill_keys( array_keys( $vehicles ), 0.0 );
	foreach ( $trips as $t ) {
		if ( isset( $by[ $t['vehicle'] ] ) ) {
			$by[ $t['vehicle'] ] += cel_claim_clean_amount( $t['distance'], 1 );
		}
	}
	$breakdown = array();
	foreach ( $by as $name => $km ) {
		$breakdown[ $name ] = array( 'km' => round( $km, 1 ), 'rate' => $vehicles[ $name ], 'amount' => round( round( $km, 1 ) * $vehicles[ $name ], 2 ) );
	}
} else {
	$breakdown = cel_claim_vehicle_breakdown( $claim );
}
$km  = array_sum( array_column( $breakdown, 'km' ) );
$net = array_sum( array_column( $breakdown, 'amount' ) );

$km_text   = function ( $n ) {
	return number_format( (float) $n, 1 ) . ' KM';
};
$rate_text = function ( $n ) {
	return 'RM ' . number_format( (float) $n, 2 ) . '/km';
};
$field     = function ( $name, $value, $type = 'text', $extra = '' ) use ( $edit ) {
	if ( $edit ) {
		return '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" ' . $extra . '>';
	}
	if ( 'date' === $type ) {
		return esc_html( cel_claim_display_date( $value ) );
	}
	if ( 'month' === $type ) {
		return esc_html( cel_claim_display_month( $value ) );
	}
	return esc_html( (string) $value );
};
$select    = function ( $name, $options, $value, $extra = '' ) use ( $edit ) {
	if ( ! $edit ) {
		return esc_html( (string) $value );
	}
	$h = '<select name="' . esc_attr( $name ) . '" ' . $extra . '>';
	foreach ( $options as $opt_value => $opt_label ) {
		$h .= '<option value="' . esc_attr( $opt_value ) . '"' . selected( (string) $value, (string) $opt_value, false ) . '>' . esc_html( $opt_label ) . '</option>';
	}
	return $h . '</select>';
};
$veh_opts = $vehicles ? array_combine( array_keys( $vehicles ), array_keys( $vehicles ) ) : array();
$pur_opts = array( '' => $edit ? '— choose —' : '' ) + ( $purposes ? array_combine( $purposes, $purposes ) : array() );
$config   = array( 'form' => 'mileage', 'vehicles' => $vehicles, 'max' => CEL_CLAIM_MAX_ROWS );

$trip_row = function ( $i, $r, $tpl = false ) use ( $edit, $field, $select, $pur_opts, $veh_opts, $first, $trips ) {
	$name = function ( $k ) use ( $i, $tpl ) {
		return $tpl ? '' : "t[$i][$k]";
	};
	$n    = function ( $k ) use ( $tpl ) {
		return $tpl ? ' data-n="' . $k . '"' : '';
	};
	$has  = ! empty( $r['date'] ) || ! empty( $r['from'] ) || ! empty( $r['to'] ) || ( isset( $r['distance'] ) && '' !== $r['distance'] );
	$dist = $r['distance'] ?? '';
	// Blank rows start with the vehicle of the last filled-in trip.
	$veh = $r['vehicle'] ?? '';
	if ( '' === $veh && $edit ) {
		$last = end( $trips );
		$veh  = $last['vehicle'] ?? $first;
	}
	ob_start();
	?>
	<tr class="m20 row<?php echo ( $i % 2 ) ? ' stripe' : ''; ?><?php echo $has || $tpl ? '' : ' is-empty'; ?>">
		<td class="c num"><?php echo $tpl ? '' : (int) ( $i + 1 ); ?></td>
		<td class="c" data-label="Date"><?php echo $field( $name( 'date' ), $r['date'] ?? '', 'date', $n( 'date' ) ); ?></td>
		<td class="c" data-label="Time of Departure"><?php echo $field( $name( 'depart' ), $r['depart'] ?? '', 'time', $n( 'depart' ) ); ?></td>
		<td class="c" data-label="Time of Arrive"><?php echo $field( $name( 'arrive' ), $r['arrive'] ?? '', 'time', $n( 'arrive' ) ); ?></td>
		<td data-label="From"><?php echo $field( $name( 'from' ), $r['from'] ?? '', 'text', 'maxlength="120"' . $n( 'from' ) ); ?></td>
		<td data-label="To"><?php echo $field( $name( 'to' ), $r['to'] ?? '', 'text', 'maxlength="120"' . $n( 'to' ) ); ?></td>
		<td class="c" data-label="Vehicle"><?php echo $has || $edit ? $select( $name( 'vehicle' ), $veh_opts, $veh, 'data-cel-veh' . $n( 'vehicle' ) ) : ''; ?></td>
		<td class="r" data-label="Distance (KM)">
			<?php
			if ( $edit ) {
				echo '<input type="number" min="0" step="0.1" inputmode="decimal" data-cel-km name="' . esc_attr( $name( 'distance' ) ) . '" value="' . esc_attr( (string) $dist ) . '"' . $n( 'distance' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
			} elseif ( '' !== $dist ) {
				echo esc_html( number_format( (float) $dist, 1 ) );
			}
			?>
		</td>
		<td data-label="Purpose of Visit"><?php echo $select( $name( 'purpose' ), $pur_opts, $r['purpose'] ?? '', $n( 'purpose' ) ); ?></td>
		<td data-label="Remarks"><?php echo $field( $name( 'remarks' ), $r['remarks'] ?? '', 'text', 'maxlength="120"' . $n( 'remarks' ) ); ?></td>
		<td class="r amt" data-label="Amount (RM)" data-cel-amt><?php echo ! $edit && isset( $r['amount'] ) ? esc_html( cel_claim_money( $r['amount'] ) ) : ''; ?></td>
	</tr>
	<?php
	return ob_get_clean();
};
// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- $field/$select/$trip_row escape their output.
?>
<div class="cel-frame cel-mileage">
<img class="cel-logo" src="<?php echo esc_url( cel_claim_logo_url() ); ?>" alt="Celectric" width="104" height="52" decoding="async">
<table class="cel-sheet cel-msheet<?php echo $edit ? ' is-edit' : ''; ?>" data-cel-sheet<?php echo $edit ? ' data-cel-config="' . esc_attr( wp_json_encode( $config ) ) . '"' : ''; ?>>
	<colgroup>
		<col style="width:30px"><col style="width:82px"><col style="width:78px"><col style="width:78px"><col style="width:135px"><col style="width:135px">
		<col style="width:90px"><col style="width:74px"><col style="width:120px"><col style="width:111px"><col style="width:90px">
	</colgroup>

	<tr class="m33 top"><td colspan="11" class="mtitle"><?php echo esc_html( cel_claim_setting( 'mileage_title' ) ); ?></td></tr>
	<tr class="m20 top datebar">
		<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
		<td class="lbl r">Date:</td>
		<td class="lb c"><?php echo esc_html( cel_claim_display_date( $claim['submission_date'] ?? '' ) ); ?></td>
	</tr>
	<tr class="m29"><td colspan="11" class="msec">1. CLAIMANT &amp; VEHICLE DETAILS</td></tr>
	<tr class="m20 info">
		<td colspan="3" class="lbl">Employee's Name:</td>
		<td colspan="3" class="lb c in"><?php echo $field( 'claimant_name', $claim['claimant_name'] ?? '', 'text', 'required maxlength="200" autocomplete="name"' ); ?></td>
		<td colspan="2" class="lbl">Claim Period / Month:</td>
		<td colspan="2" class="lb in"><?php echo $field( 'claim_period', $claim['claim_period'] ?? '', 'month', 'required' ); ?></td>
		<td class="pad"></td>
	</tr>
	<tr class="m20 info">
		<td colspan="3" class="lbl">Rate Options:</td>
		<td colspan="7" class="tot b"><?php echo esc_html( $claim['rate_options'] ?? '' ); ?><?php echo $edit ? ' <span class="cel-auto">– choose the vehicle on each trip</span>' : ''; ?></td>
		<td class="pad"></td>
	</tr>
	<tr class="m20 blank"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	<tr class="m32 mhead">
		<td>No.</td><td>Date</td><td>Time of Departure</td><td>Time of Arrive</td><td>From</td><td>To</td><td>Vehicle</td><td>Distance (KM)</td><td>Purpose of Visit</td><td>Remarks</td><td>Amount (RM)</td>
	</tr>
	<tbody data-cel-rows="t">
	<?php
	for ( $i = 0; $i < $rows; $i++ ) {
		echo $trip_row( $i, $trips[ $i ] ?? array() );
	}
	?>
	</tbody>
	<tr class="m29 subrow">
		<td colspan="7" class="mtot-l">TOTAL MILEAGE &amp; CLAIM AMOUNT</td>
		<td class="tot b r" data-cel-km-total><?php echo esc_html( $km_text( $km ) ); ?></td>
		<td colspan="2" class="mtot-l">Total Claim Amount:</td>
		<td class="mnet r" data-cel-net><?php echo esc_html( 'RM ' . cel_claim_money( $net ) ); ?></td>
	</tr>
	<tr class="m20 blank"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	<tr class="m29"><td colspan="11" class="msec">2. CLAIM SUMMARY BREAKDOWN</td></tr>
	<?php
	$shown = $edit ? $breakdown : ( $breakdown ? $breakdown : array( $first => array( 'km' => 0, 'rate' => $vehicles[ $first ] ?? 0, 'amount' => 0 ) ) );
	foreach ( $shown as $vname => $v ) :
		?>
	<tr class="m26 sumrow vehrow" data-cel-vrow="<?php echo esc_attr( $vname ); ?>">
		<td colspan="3" class="lbl"><?php echo esc_html( $vname ); ?>:</td>
		<td colspan="3" class="tot b c" data-cel-vkm><?php echo esc_html( $km_text( $v['km'] ) ); ?></td>
		<td colspan="2" class="c">× <?php echo esc_html( $rate_text( $v['rate'] ) ); ?></td>
		<td colspan="2" class="r">=</td>
		<td class="tot b r" data-cel-vamt><?php echo esc_html( 'RM ' . cel_claim_money( $v['amount'] ) ); ?></td>
	</tr>
		<?php
	endforeach;
	?>
	<tr class="m26 sumrow">
		<td colspan="3" class="lbl">Total Distance (KM):</td>
		<td colspan="3" class="tot b c" data-cel-km-total><?php echo esc_html( $km_text( $km ) ); ?></td>
		<td colspan="3" class="lbl r">Net Payable Claim:</td>
		<td colspan="2" class="mnet c" data-cel-net data-cel-grand><?php echo esc_html( 'RM ' . cel_claim_money( $net ) ); ?></td>
	</tr>
</table>
</div>
<?php if ( $edit ) : ?>
<template data-cel-tpl="t"><?php echo $trip_row( 0, array(), true ); ?></template>
<?php endif; ?>
<?php // phpcs:enable ?>
